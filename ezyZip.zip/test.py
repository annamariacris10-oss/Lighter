import tkinter as tk
from tkinter import filedialog, messagebox
import librosa
import numpy as np
import serial
import serial.tools.list_ports
import threading
import time
import json
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt

# ---------------- GLOBALS ----------------
projects_file = "vixen_projects.json"
arduino = None
songs = []  # list of songs in project
current_song_index = 0
y, sr = None, None
running = False
paused = False
preview_mode = True  # default preview mode

# ---------------- UTILITIES ----------------
def list_ports():
    ports = [port.device for port in serial.tools.list_ports.comports()]
    if ports:
        port_var.set(ports[0])
    return ports

def add_song():
    global songs, y, sr
    path = filedialog.askopenfilename(title="Select Music File", filetypes=[("Audio Files","*.mp3 *.wav")])
    if path:
        songs.append(path)
        song_listbox.insert(tk.END, path.split('/')[-1])
        if len(songs) == 1:
            load_song(0)

def load_song(index):
    global y, sr, current_song_index
    if 0 <= index < len(songs):
        current_song_index = index
        path = songs[index]
        y, sr = librosa.load(path, sr=None, mono=True)
        plot_waveform(y, sr)
        song_listbox.select_clear(0, tk.END)
        song_listbox.select_set(index)

def plot_waveform(y, sr):
    for widget in waveform_frame.winfo_children():
        widget.destroy()
    fig, ax = plt.subplots(figsize=(8,2))
    times = np.arange(len(y))/sr
    ax.plot(times, y, color='blue')
    ax.set_title("Waveform")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    canvas = FigureCanvasTkAgg(fig, master=waveform_frame)
    canvas.draw()
    canvas.get_tk_widget().pack()

def connect_arduino():
    global arduino, preview_mode
    try:
        arduino = serial.Serial(port_var.get(), 115200)
        time.sleep(2)
        preview_mode = False
        messagebox.showinfo("Arduino", f"Connected to {port_var.get()}")
    except:
        preview_mode = True
        messagebox.showwarning("Arduino","Failed to connect. Running in preview mode.")

def send_to_arduino(r,g,b):
    if arduino:
        command = f"{r},{g},{b}\n"
        arduino.write(command.encode())

# ---------------- EFFECTS ----------------
def apply_effect(effect, value):
    if effect == "fade":
        return int(value * 0.7)
    elif effect == "strobe":
        return int(value * (np.random.randint(0,2)))
    elif effect == "pulse":
        return int(value * (np.sin(time.time()*10)**2))
    else:
        return value

# ---------------- MUSIC SYNC ----------------
def sync_music():
    global running, paused
    if y is None:
        messagebox.showerror("Error","No song loaded")
        return
    frame_size = 1024
    hop_size = 512
    num_frames = int(np.ceil((len(y)-frame_size)/hop_size))
    start_time = time.time()
    running = True

    r_effect = r_effect_var.get()
    g_effect = g_effect_var.get()
    b_effect = b_effect_var.get()

    for i in range(num_frames):
        if not running: break
        while paused: time.sleep(0.1)

        start = i*hop_size
        end = start+frame_size
        frame = y[start:end]
        if len(frame)<frame_size: frame=np.pad(frame,(0,frame_size-len(frame)))

        # FFT features
        fft = np.fft.rfft(frame)
        freqs = np.fft.rfftfreq(len(frame),1/sr)
        low = np.mean(np.abs(fft[(freqs>=20)&(freqs<250)]))
        mid = np.mean(np.abs(fft[(freqs>=250)&(freqs<2000)]))
        high = np.mean(np.abs(fft[(freqs>=2000)]))
        low_val = int(np.clip(low*1000,0,255))
        mid_val = int(np.clip(mid*1000,0,255))
        high_val = int(np.clip(high*1000,0,255))

        # Apply effects
        r = apply_effect(r_effect, low_val)
        g = apply_effect(g_effect, mid_val)
        b = apply_effect(b_effect, high_val)

        # Update LED bars via IntVar
        r_var.set(r)
        g_var.set(g)
        b_var.set(b)
        root.update_idletasks()

        # Send to Arduino if not in preview
        if not preview_mode:
            send_to_arduino(r,g,b)

        # timing
        while time.time()-start_time < i*hop_size/sr:
            if not running: break
            time.sleep(0.001)
    running=False

# ---------------- BUTTON COMMANDS ----------------
def start():
    if not songs: messagebox.showerror("Error","Add a song first"); return
    threading.Thread(target=sync_music, daemon=True).start()

def stop():
    global running, paused
    running=False; paused=False
    r_var.set(0); g_var.set(0); b_var.set(0)
    if not preview_mode: send_to_arduino(0,0,0)

def pause():
    global paused
    paused = not paused

def save_project():
    project = {
        "name": project_name_var.get(),
        "songs": songs,
        "r_effect": r_effect_var.get(),
        "g_effect": g_effect_var.get(),
        "b_effect": b_effect_var.get()
    }
    try:
        try:
            with open(projects_file,"r") as f: data=json.load(f)
        except: data=[]
        data.append(project)
        with open(projects_file,"w") as f: json.dump(data,f,indent=4)
        messagebox.showinfo("Save","Project saved successfully")
    except Exception as e:
        messagebox.showerror("Error",str(e))

def load_project():
    try:
        with open(projects_file,"r") as f: data=json.load(f)
        if not data: messagebox.showinfo("Load","No saved projects"); return
        project = data[-1]  # load last
        project_name_var.set(project.get("name",""))
        r_effect_var.set(project.get("r_effect","None"))
        g_effect_var.set(project.get("g_effect","None"))
        b_effect_var.set(project.get("b_effect","None"))
        global songs
        songs = project.get("songs",[])
        song_listbox.delete(0,tk.END)
        for s in songs: song_listbox.insert(tk.END,s.split('/')[-1])
        if songs: load_song(0)
        messagebox.showinfo("Load","Project loaded")
    except Exception as e:
        messagebox.showerror("Error",str(e))

# ---------------- GUI ----------------
root=tk.Tk()
root.title("AK LIGHTS SHOWS")

# Project Name
tk.Label(root,text="Project Name:").grid(row=0,column=0,padx=10,pady=5)
project_name_var=tk.StringVar()
tk.Entry(root,textvariable=project_name_var).grid(row=0,column=1,padx=10,pady=5)

# Arduino Port
tk.Label(root,text="Arduino Port:").grid(row=1,column=0,padx=10,pady=5)
port_var=tk.StringVar()
tk.OptionMenu(root,port_var,*list_ports()).grid(row=1,column=1,padx=10,pady=5)
tk.Button(root,text="Connect Arduino",command=connect_arduino).grid(row=1,column=2,padx=10,pady=5)

# Songs
tk.Button(root,text="Add Song",command=add_song).grid(row=2,column=0,padx=10,pady=5)
song_listbox=tk.Listbox(root,width=40)
song_listbox.grid(row=2,column=1,columnspan=2,padx=10,pady=5)
song_listbox.bind("<<ListboxSelect>>",lambda e: load_song(song_listbox.curselection()[0] if song_listbox.curselection() else 0))

# Waveform
waveform_frame=tk.Frame(root)
waveform_frame.grid(row=3,column=0,columnspan=3,padx=10,pady=10)

# LED Bars using IntVar
r_var = tk.IntVar()
g_var = tk.IntVar()
b_var = tk.IntVar()

r_bar = tk.Scale(root,label="Red (Bass)",from_=0,to=255,orient='horizontal',length=200,variable=r_var)
r_bar.grid(row=4,column=0)
g_bar = tk.Scale(root,label="Green (Mid)",from_=0,to=255,orient='horizontal',length=200,variable=g_var)
g_bar.grid(row=4,column=1)
b_bar = tk.Scale(root,label="Blue (High)",from_=0,to=255,orient='horizontal',length=200,variable=b_var)
b_bar.grid(row=4,column=2)

# Effects
r_effect_var=tk.StringVar(value="None")
g_effect_var=tk.StringVar(value="None")
b_effect_var=tk.StringVar(value="None")
tk.OptionMenu(root,r_effect_var,"None","fade","strobe","pulse").grid(row=5,column=0)
tk.OptionMenu(root,g_effect_var,"None","fade","strobe","pulse").grid(row=5,column=1)
tk.OptionMenu(root,b_effect_var,"None","fade","strobe","pulse").grid(row=5,column=2)

# Controls
tk.Button(root,text="Start",bg="green",fg="white",command=start).grid(row=6,column=0,padx=10,pady=10)
tk.Button(root,text="Pause",bg="orange",fg="white",command=pause).grid(row=6,column=1,padx=10,pady=10)
tk.Button(root,text="Stop",bg="red",fg="white",command=stop).grid(row=6,column=2,padx=10,pady=10)

# Save/Load
tk.Button(root,text="Save Project",command=save_project).grid(row=7,column=0,padx=10,pady=10)
tk.Button(root,text="Load Last Project",command=load_project).grid(row=7,column=1,padx=10,pady=10)

root.mainloop()
